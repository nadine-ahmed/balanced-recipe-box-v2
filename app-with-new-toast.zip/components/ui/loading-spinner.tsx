import { Spinner } from "@/components/ui/spinner"

export function LoadingSpinner() {
  return <Spinner aria-label="Loading content" />
}

